import 'package:flutter/material.dart';

class SpacingStyles{
  static const  EdgeInsets withAppBarPadding = EdgeInsets.fromLTRB(20, 90, 20, 10);
  static const  EdgeInsets withOutAppBarPadding = EdgeInsets.fromLTRB(20, 0, 20, 10);
}