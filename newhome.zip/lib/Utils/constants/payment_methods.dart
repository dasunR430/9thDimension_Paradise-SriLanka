class PaymentMethods{
  static const String cashOnDelivery = "Cash On Delivery";
  static const String freshPay = "FreshPay";
}